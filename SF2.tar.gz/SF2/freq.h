void getfreq(char *outfn);
double *loadfreq(char *infn);
double likelihood_freq_onesnp(int x, int n, int folded, int count, double *p);
