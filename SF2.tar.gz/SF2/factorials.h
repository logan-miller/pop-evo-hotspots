#ifndef __FAC_H__
#define __FAC_H__

void get_factorials(int n);
double factorial(int n);
double ln_factorial(int n);
double xchoosey(int x, int y);
double ln_xchoosey(int x, int y);
double multinom(int x, int n, ...);
#endif
