void dsort(int n,double *arr);
void isort(int n,int *arr);
void sort2(unsigned long n, double arr[], int brr[]);
